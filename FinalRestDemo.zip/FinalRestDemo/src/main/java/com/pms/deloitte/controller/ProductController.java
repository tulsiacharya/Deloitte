package com.pms.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.pms.deloitte.ProductDAO.ProductDAO;
import com.pms.deloitte.model.Product;
import com.pms.deloitte.service.ProductService;
@RestController
@RequestMapping("product")
public class ProductController
{
	@Autowired
	ProductService productService;
	@RequestMapping("getProduct")
	public List<Product> Product()
	{
		
		List<Product> allProduct=productService.listProducts();
	
		return allProduct;
	}
	/*@RequestMapping("/addProduct")
	public ModelAndView addProduct(Product product)
	{
		System.out.println("ADDING ############");
		ModelAndView view =new ModelAndView("redirect:/Product");
		System.out.println(product);
		
		view.addObject("product",new Product());
		

		productService.addProduct(product);
		return view;
	}
	
	@RequestMapping(value="/updateProduct/add/update")
	public String updatePerson(Product product)
	{
		System.out.println("EDit####");
		this.productService.updateProduct(product);
		return"redirect:/Product";
	}
	
	@RequestMapping("/updateProduct/{prodId}")
	public ModelAndView updateProduct(@PathVariable("prodId")Integer productId)
	{
		System.out.println("$$$$$$$$Update");
		ModelAndView view =new ModelAndView("product");
		Product product =productService.getProduct(productId);
		List<Product> allListProduct=productService.listProducts();
		view.addObject("allProduct",allListProduct);
		view.addObject("product",product);

		return view;
	}

	@RequestMapping("/deleteProduct/{prodId}")
	public ModelAndView deleteProduct(@PathVariable("prodId")Integer productId)
	{
		productService.deleteProduct(productId);
		ModelAndView view =new ModelAndView("redirect:/Product");
		view.addObject("product",new Product());
		System.out.println("###tulsi deleted");
		return view;
	}*/


}
