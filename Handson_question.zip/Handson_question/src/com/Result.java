package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Result extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Result() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		String a1=(String) session.getAttribute("a1");
		String a2=(String) session.getAttribute("a2");
		String a3=(String) session.getAttribute("a3");
		PrintWriter out = response.getWriter();
		out.println(" Correct answer      Your answer");
		out.println("1."+"A \t"+a1);
		out.println("2."+"B \t"+a2);
		out.println("3."+"C \t"+a3);
		int res=0;
		if(a1.equals("A"))
		{
			res+=10;
		}
		if(a2.equals("B"))
		{
			res+=10;
		}
		if(a2.equals("C"))
		{
			res+=10;
		}

		out.println("Your result is::"+res);

		
	}

}
