package project_j2;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class DemoCopy 
{
	public static void main(String[] args) throws IOException
	{
		Scanner sc=new 
		FileReader fr=new FileReader("mohan.txt");
		FileWriter fw=new FileWriter("record.txt");
		int i=0;
		while((i=fr.read())!=-1)
		{
			fw.write((char)i);
		}
		fw.close();
		fr.close();
		
		
	}

}
