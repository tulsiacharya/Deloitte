package project_j2;

import java.io.File;
import java.io.IOException;

public class DemoFile
{
	public static void main(String[] args) throws IOException 
	{
		File file=new File("c:\\deloitte\\Batch\\BatchMates.txt");
		file.createNewFile();
		File folder =new File("c:\\deloitte\\Batch");
		File f[]=folder.listFiles();
		int c=0;
		int t=0;
		for(File f1:f)
		{
			if(f1.isFile())
			{
				System.out.println("The file is "+f1.getName());
				c++;
			}
			if(f1.isDirectory())
			{
				System.out.println("The folder is:"+f1.getName());
				t++;
			}
		}
		System.out.println("Number of files::"+ c);
		System.out.println("Number of folders::"+ t);

		
		
		
	}
}
