package project_j2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Demo_Shortcut 
{
	public static void main() throws IOException 
	{
		BufferedReader bufferReader=new BufferedReader(new FileReader(new File("mohan.txt")));
		BufferedWriter  bufferedWriter=new BufferedWriter(new FileWriter(new File("sharma.txt")));
		int i=0;
		while((i=bufferReader.read())!=-1)
		{
			bufferedWriter.write((char)i);
		}
		bufferedWriter.close();
		bufferReader.close();
		
	}
	
}
