package project_j2;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Demo1
{
	public static void main(String[] args) throws IOException
	{
		File file =new File("mohan.txt");
		FileReader reader= new FileReader(file);
		int i=0;
		while((i=reader.read())!=-1) {
			System.out.print((char)i);
		}
		reader.close();
	}

}
