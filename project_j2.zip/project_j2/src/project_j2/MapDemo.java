package project_j2;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo
{
	public static void main(String[] args)
	{
		HashMap<String,Double> hm=new HashMap<String,Double>();
		hm.put("John Doe",new Double(342.23));
		hm.put("Rohan",new Double(381.43));
		hm.put("Tom Holland",new Double(456.23));
		hm.put("Ralf Lauren", new Double(873.12));
		
		Set set=hm.entrySet();
		Iterator i=set.iterator();
		
		while(i.hasNext())
		{
			Map.Entry me=(Map.Entry)i.next();
			System.out.print(me.getKey()+":");
			System.out.println(me.getValue());
		}
		System.out.println();
		double balance=((Double) hm.get("John Doe")).doubleValue();
		hm.put("John Doe", new Double(balance + 100));
		
		System.out.println(hm);


		
	}
}
