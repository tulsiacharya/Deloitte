package project_j2;

import java.io.Serializable;
import java.util.Scanner;

public class Customer implements Serializable, Comparable<Customer>
{
	private int customeId;
	private String customeName;
	private String customeAddress;
	private transient int billMount;
	
	public Customer()
	{
		
	}

	public Customer(int customeId, String customeName, String customeAddress, int billMount) {
		super();
		this.customeId = customeId;
		this.customeName = customeName;
		this.customeAddress = customeAddress;
		this.billMount = billMount;
	}
	public void accept()
	{
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter customer id : "); customeId = scanner.nextInt();
        System.out.println("Enter customer name : "); customeName = scanner.next();
        System.out.println("Enter customer address : "); customeAddress = scanner.next();
        System.out.println("Enter bill amount : "); billMount = scanner.nextInt();
    }

	public int getCustomeId() {
		return customeId;
	}

	public void setCustomeId(int customeId) {
		this.customeId = customeId;
	}

	public String getCustomeName() {
		return customeName;
	}

	public void setCustomeName(String customeName) {
		this.customeName = customeName;
	}

	public String getCustomeAddress() {
		return customeAddress;
	}

	public void setCustomeAddress(String customeAddress) {
		this.customeAddress = customeAddress;
	}

	public int getBillMount() {
		return billMount;
	}

	public void setBillMount(int billMount) {
		this.billMount = billMount;
	}

	@Override
	public String toString() {
		return "\nCustomer [customeId=" + customeId + ", customeName=" + customeName + ", customeAddress="
				+ customeAddress + ", billMount=" + billMount + "]";
	}

	@Override
	public int compareTo(Customer o) {
		if(this.billMount<o.billMount)
			return -1;
		else
			return 0;
	}
	
}
