package project_j2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


public class Generic
{
	public static void main(String[] args)
	{

		List<Customer> customerDetail = new ArrayList<Customer>();
		
		Customer customer1=new Customer(100,"Jaya","pune",8000);
		
		customerDetail.add(customer1);
		customerDetail.add(new Customer(101,"Mohan","banglore",9000));
		customerDetail.add(new Customer(102,"Rohan","bombay",9900));
		customerDetail.add(new Customer(103,"Neha","jaipur",9000));
		
		System.out.println(customerDetail);
		System.out.println("Sort on 1)name 2)address 3)bill amount");
		Scanner sc=new Scanner(System.in);
		System.out.println("-------------------------------------------");

		int choice=sc.nextInt();
		if(choice==1)
		{
			Collections.sort(customerDetail, new NameComparator());
			System.out.println(customerDetail);

		}
		
		
		if(choice==3)
		{	
			Collections.sort(customerDetail);
			System.out.println(customerDetail);
		}
		
		if(choice==2)
		{
			Collections.sort(customerDetail,new Comparator<Customer>() {

				@Override
				public int compare(Customer o1, Customer o2) {
					if(o1.getCustomeAddress().compareTo(o2.getCustomeAddress())>0)
					{
						return 0;
					}
					else
					{
						return -1;
					}
				}
			});
		}
		
		

		
		
	}
	
}
