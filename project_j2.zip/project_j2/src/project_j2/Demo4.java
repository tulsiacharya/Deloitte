package project_j2;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Demo4
{
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException
	{
		Customer cust=new Customer();
		ObjectInputStream stream=new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("delu.txt"))));
		cust=(Customer)stream.readObject();
		System.out.println(cust);
		
	}
}
