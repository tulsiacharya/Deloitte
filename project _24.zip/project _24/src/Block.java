
public class Block
{
	{
		System.out.println("instance block");
	}
	static
	{
		System.out.println("static block");
	}
	public Block()
	{
		System.out.println("Block constructor");
	}
	public static void main(String[] args) 
	{
		System.out.println("in main");
		new Block();
		new Block();
	}
}
