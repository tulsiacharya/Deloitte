
public class Demo
{
	public static void main(String[] args) 
	{
		Customer customer1=new Customer();
		Customer customer2=new Customer(700,"tulsi","banglore",2001);
		customer1.display();
		customer1.setCustomerName("kalpana");
		customer1.display();
		customer2.display();

	}
}
