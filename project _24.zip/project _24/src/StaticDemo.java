
public class StaticDemo {

}
