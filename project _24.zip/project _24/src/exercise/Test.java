package exercise;

import java.util.StringTokenizer;

public class Test 
{
	public void show(String s)
	{
		char ch=s.charAt(12);
		System.out.println("chracter at 12h index is"+ch);
		boolean check=s.contains("is");
		System.out.println(check);
		System.out.println(s.concat("and killed it"));
		boolean shw=s.endsWith("dog");
		System.out.println(shw);
		String str="The quick brown Fox jumps over the lazy Dog";
		boolean t=s.equals(str);
		System.out.println(t);
		String tr="THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG";
		boolean b=s.equals(tr);
		System.out.println(b);
		System.out.println(s.length());
		System.out.println(s.matches(str));
		System.out.println(s.replace("The","A"));
		System.out.println(s.toLowerCase());
		System.out.println(s.toUpperCase());
		System.out.println(s.indexOf("a"));
		System.out.println(s.lastIndexOf("e"));
		int n=s.indexOf("Fox");
		System.out.println(s.substring(0,n+3));
		System.out.println(s.substring(n+4,s.length()-1));
		StringTokenizer st =new StringTokenizer(s);
		while(st.hasMoreTokens())
		{
			if(st.nextToken().equals("Fox")||st.nextToken().equals("dog"))
			{
				System.out.println(st.nextToken());
			}
		}
		
		
		
	}
	public static void main(String[] args)
	{
		Test t=new Test();
		String s="The quick brown Fox jumps over the lazy dog ";
		t.show(s);
	}
}
