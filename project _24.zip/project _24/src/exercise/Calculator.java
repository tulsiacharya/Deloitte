package exercise;

public class Calculator 
{
	public void add(int a,int b)
	{
		System.out.println(a+b);
		
	}
	public void add(double a,double b)
	{
		System.out.println(a+b);
	}
	public void add(int a,double b)
	{
		System.out.println(a+b);
	}
	public void add(double a,int b)
	{
		System.out.println(a+b);
	}
	public void diff(int a,int b)
	{
		System.out.println(a-b);
	}
	public void diff(double a,double b)
	{
		System.out.println(a-b);
	}
	public void diff(int a,double b)
	{
		System.out.println(a-b);
	}
	public void diff(double a,int b)
	{
		System.out.println(a-b);
	}
	public void mul(int a,int b)
	{
		System.out.println(a*b);
	}
	public void mul(double a,double b)
	{
		System.out.println(a*b);
	}
	public void mul(int a,double b)
	{
		System.out.println(a*b);
	}
	public void mul(double a,int b)
	{
		System.out.println(a*b);
	}
	public void div(int a,int b)
	{
		System.out.println(a/b);
	}
	public void div(double a,double b)
	{
		System.out.println(a/b);
	}
	public void div(int a,double b)
	{
		System.out.println(a/b);
	}
	public void div(double a,int b)
	{
		System.out.println(a/b);
	}
	
	public static void main(String[] args) 
	{
		Calculator cl=new Calculator();
		cl.mul(55, 11);
		cl.mul(23, 40.00);
		cl.mul(49.89, 98.45);
		cl.mul(456.6, 10);
		cl.add(56, 78);
		cl.add(45,87.90);
		cl.add(45.78, 78);
		cl.add(45.56, 67.78);
		cl.diff(567.78,567.6);
		cl.diff(34.45,56);
		cl.diff(23,9);
		cl.diff(45, 46.87);
		cl.div(34.67, 6.98);
		cl.div(45, 9);
		cl.div(34,7.6);
		cl.div(345,4.5);
	}
	

}
