package com.rms.deloitte.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rms.deloitte.dao.OrderDAO;
import com.rms.deloitte.model.Order;
@Service
public class OrderServiceImpl implements OrderService {
 @Autowired
 OrderDAO orderDAO;

@Override
@Transactional
public void addOrder(Order order) {
	orderDAO.save(order);
	// TODO Auto-generated method stub
	
}

@Override
@Transactional
public void deleteOrder(int orderId) {
	orderDAO.deleteById(orderId);
	// TODO Auto-generated method stub
	
}

@Override
@Transactional
public void updateOrder(Order order) {
	if(orderDAO.existsById(order.getOrderId()))
		orderDAO.save(order);
	// TODO Auto-generated method stub
	
}

@Override
@Transactional
public Order getOrder(int orderId) {
	Optional<Order> optionalOrder=orderDAO.findById(orderId);
	Order order=new Order();
	if(optionalOrder.isPresent()) {
		order=optionalOrder.get();
	}
	// TODO Auto-generated method stub
	return order;
	
	
}
	// TODO Auto-generated method stub
	

@Override
@Transactional
public boolean isOrderExists(int orderId) {
	// TODO Auto-generated method stub
	return orderDAO.existsById(orderId);
}

@Override
@Transactional
public List<Order> listOrders() {
	// TODO Auto-generated method stub
	return (List<Order>)orderDAO.findAll();
}

@Override
@Transactional
public List<Order> listOrders(String waiterName) {
	// TODO Auto-generated method stub
	return orderDAO.findByWaiterName(waiterName);
	
}

@Override
@Transactional
public void deleteOrders(String waiterName) {
	// TODO Auto-generated method stub
	orderDAO.deleteByWaiterName(waiterName);
}


}
