package question_2;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

class EmplyeeVo{
	private int empid;
	private String empname;
	private double annualincome;
	private double incometax;
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public double getAnnualincome() {
		return annualincome;
	}
	public void setAnnualincome(double annualincome) {
		this.annualincome = annualincome;
	}
	public double getIncometax() {
		return incometax;
	}
	public void setIncometax(double incometax) {
		this.incometax = incometax;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(annualincome);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + empid;
		result = prime * result + ((empname == null) ? 0 : empname.hashCode());
		temp = Double.doubleToLongBits(incometax);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmplyeeVo other = (EmplyeeVo) obj;
		if (Double.doubleToLongBits(annualincome) != Double.doubleToLongBits(other.annualincome))
			return false;
		if (empid != other.empid)
			return false;
		if (empname == null) {
			if (other.empname != null)
				return false;
		} else if (!empname.equals(other.empname))
			return false;
		if (Double.doubleToLongBits(incometax) != Double.doubleToLongBits(other.incometax))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "EmplyeeVo [empid=" + empid + ", empname=" + empname + ", annualincome=" + annualincome + ", incometax="
				+ incometax + "]";
	}
    
    
}




class EmplyeeBo{
	
	public static void calincomeTax(EmplyeeVo emp) {
		
		double income=emp.getAnnualincome();
		
		if(income<500000) {
			emp.setIncometax(0);
		}else if(income<1000000){
			emp.setIncometax(0.1*income);
		}else if(income<2000000)
		{
			emp.setIncometax(0.2*income);
		}
		else
		{
			emp.setIncometax(0.3*income);
		}
	} 
	
} 





class Employeesort implements Comparator<EmplyeeVo> {

	

	@Override
	public int compare(EmplyeeVo o1, EmplyeeVo o2) {
		int x= (int)o2.getIncometax()-(int)o1.getIncometax();
		if(x>0) {
			return 1;
		}
		else if(x==0) {
			return 0;
		}
		else if(x<0) {
			return -1;
		}
		return 0;
	}
}


public class EmplyeeMain {

	static void display(EmplyeeVo[] emp) {
		System.out.println("printing   ..");
		for (int i = 0; i < emp.length; i++) {
			System.out.println(emp[i]);
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("no of employees");
		int len=sc.nextInt();
		EmplyeeVo[] emp=new EmplyeeVo[len];
		
		for (int i = 0; i < emp.length; i++) {
			emp[i]=new EmplyeeVo();
			System.out.println("enter for employee "+(i+1));
			System.out.println("id");
			emp[i].setEmpid(sc.nextInt());
			System.out.println("name");
			emp[i].setEmpname(sc.next());
			System.out.println("salary");
			emp[i].setAnnualincome(sc.nextDouble());
			
			
			EmplyeeBo.calincomeTax(emp[i]);
			
		}
		
		display(emp);
		
		List<EmplyeeVo> list = Arrays.asList(emp);
		Collections.sort(list, new Employeesort());

		System.out.println("sorted");
		
		System.out.println(list);

		
		
		
	}
	
}


