package question_1;

import java.util.Scanner;

abstract class Arithmetic{
	int num1,num2;
	public Arithmetic() {
		// TODO Auto-generated constructor stub
	}

	void read() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter numbers");
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		int result=calculate(num1,num2);
		display(result);
	}
	void display(int result) {
		System.out.println(result);
	}
	 abstract int calculate(int a,int b);
	
	
}
 class Addition extends Arithmetic {
	@Override
	 int calculate(int a, int b) {
		return a+b;
	}

}
 class Subtraction extends Arithmetic {
		@Override
		 int calculate(int a, int b) {
			return a-b;
		}

	}

 class Multiplication extends Arithmetic {
		@Override
		 int calculate(int a, int b) {
			return a*b;
		}

	}
 class Division extends Arithmetic {
		@Override
		 int calculate(int a, int b) {
			return a/b;
		}

	}


 

public class Calculator {

	public static void main(String[] args) {
		
		Arithmetic arr[]= {new Addition(), new Subtraction(), new Multiplication(), new Division()};
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter your choice:\n1. Addition\n2. Sub\n3. Multiply\n4. Divide");
		int choice=sc.nextInt();
		
		
		arr[choice-1].read();
		
		
//		
	}
}




