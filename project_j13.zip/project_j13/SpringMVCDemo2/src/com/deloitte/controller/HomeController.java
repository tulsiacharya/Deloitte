package com.deloitte.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController
{
	    @RequestMapping("/employee")
		public String gg()
		{
			return "emp";
			
		}
	    @RequestMapping("/customer")
		public String pp()
		{
			return "cust";
		}
	    
	    @RequestMapping("/product")
		public String hh()
		{
			return "prdt";
		}
	    
	    @RequestMapping("/guest")
		public String ss()
		{
			return "gst";
		}
	    
}
