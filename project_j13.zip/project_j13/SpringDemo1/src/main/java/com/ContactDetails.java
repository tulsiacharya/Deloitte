package com;

public class ContactDetails 
{
	private String phoneNo;
	private String email;
	
	public ContactDetails()
	{
		// TODO Auto-generated constructor stub
	}
	
	
	public ContactDetails(String phoneNo, String email) {
		super();
		this.phoneNo = phoneNo;
		this.email = email;
	}


	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	@Override
	public String toString() {
		return "ContactDetails [phoneNo=" + phoneNo + ", email=" + email + "]";
	}
	
	

}
