package com;

import java.io.Serializable;
import java.util.Scanner;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import javax.annotation.*;


public class Customer implements Serializable,InitializingBean,DisposableBean
{

	private int customerId;
	private String customerName;
	private String customerAddress;
	private int billAmount;
	
	@Autowired
	private ContactDetails contactdetails;
	
	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", billAmount=" + billAmount + ", contactdetails=" + contactdetails + "]";
	}
	
	public Customer()
	{
		
	}
	@PostConstruct
	public void dd()
	{
		System.out.println("########INIT############");
	}
	@PreDestroy
	public void dd2()
	{
		System.out.println("###DESTROY########");
	}
	public Customer(int customerId, String customerName, String customerAddress, int billAmount,
			ContactDetails contactdetails) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.billAmount = billAmount;
		this.contactdetails = contactdetails;
		System.out.println("Constructor called");
	}
	public Customer(int customerId, ContactDetails contactdetails) {
		super();
		this.customerId = customerId;
		this.contactdetails = contactdetails;
	}

	public ContactDetails getContactdetails() {
		return contactdetails;
	}

	public void setContactdetails(ContactDetails contactdetails) {
		this.contactdetails = contactdetails;
	}

	public Customer(int customeId, String customeName, String customeAddress, int billMount) {
		super();
		this.customerId = customeId;
		this.customerName = customeName;
		this.customerAddress = customeAddress;
		this.billAmount = billMount;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public int getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}
	public void accept()
	{
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter customer id : "); customerId = scanner.nextInt();
        System.out.println("Enter customer name : "); customerName = scanner.next();
        System.out.println("Enter customer address : "); customerAddress = scanner.next();
        System.out.println("Enter bill amount : "); billAmount = scanner.nextInt();
    }

	public void destroy() throws Exception {
		System.out.println("Destroy by interface");
		
	}

	public void afterPropertiesSet() throws Exception
	{
		System.out.println("INITIALISE");
		
	}
	
}
