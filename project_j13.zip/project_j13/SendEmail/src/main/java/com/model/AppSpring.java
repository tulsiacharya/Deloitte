package com.model;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.config.AppConfig;

/**
 * Hello world!
 *
 */
public class AppSpring 
{
    public static void main( String[] args )
    {
    	//Resource resource = new ClassPathResource("beans.xml");
    	ApplicationContext context= new AnnotationConfigApplicationContext(AppConfig.class);
    	//BeanFactory factory=new XmlBeanFactory(resource);
    	Email email=context.getBean(Email.class);
    	To to=context.getBean(To.class);
    	to.setToEmail("tulsiacharya@gmail.com");
    	to.setToName("Tulsi");
    	From from=context.getBean(From.class);
    	from.setFromName("Neha");
    	from.setFromEmail("Neha@gmail.com");
    	Subject subject=context.getBean(Subject.class);
    	subject.setCaption("Reading");
    	Body body=context.getBean(Body.class);
    	body.setMessage("Books need to be sent");
    	
    	System.out.println(email);
    	
    	
    }
}
