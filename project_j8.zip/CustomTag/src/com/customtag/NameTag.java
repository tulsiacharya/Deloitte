package com.customtag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class NameTag extends TagSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int noOfTimes=2;
	private String nameToPrint;
	private String color;
	
	
	public NameTag() {
		// TODO Auto-generated constructor stub
	}
@Override
public int doStartTag() throws JspException {
	JspWriter out = pageContext.getOut();
     for(int i=0;i<=noOfTimes;i++)
     {
    	 try {
			out.println(nameToPrint+"<br/>");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     }
	
	
	
	return super.doStartTag();
}
public int getNoOfTimes() {
	return noOfTimes;
}
public void setNoOfTimes(int noOfTimes) {
	this.noOfTimes = noOfTimes;
}
public String getNameToPrint() {
	return nameToPrint;
}
public void setNameToPrint(String nameToPrint) {
	this.nameToPrint = nameToPrint;
}

public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}


	
}
