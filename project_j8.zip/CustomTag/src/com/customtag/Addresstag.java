package com.customtag;

import java.io.IOException;

import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class Addresstag extends TagSupport
{
	public int doStartTag()
	{
		JspWriter out=pageContext.getOut();
		try
		{
			out.println("Deloitte<br/>");
			out.println("Block C,Divyashree Technopolies");
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		return 0;
		
	}
	
}
