package com.deloitte.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;

import co.cms.deloitte.service.CustomerService;

@Controller
public class CustomerController {
	@Autowired
	CustomerService customerService;
	@RequestMapping("/customersave")
	public ModelAndView savecustomerDetails(Customer customer) {
		
		System.out.println(customer);
		customerService.addCustomer(customer);
		ModelAndView view=new ModelAndView();
		view.setViewName("result");
		view.addObject("custo", customer);
		return view;
	}
	
	@RequestMapping("/CustomerUpdate")
	public ModelAndView updateCustomerDetails(Customer customer) {
		
		System.out.println(customer);
		
		ModelAndView view =new ModelAndView();
		System.out.println("Controller called");
		view.addObject("custo", customer);
		if(customerService.isCustomerExists(customer.getCustomerId())) {
		
			customerService.updateCustomer(customer);
			view.addObject("custo", customer);	
			view.setViewName("result");
		}else {
			view.setViewName("error");
			
		}
		
		return view;
		
	}
	
	@RequestMapping("/printDetails")
	public ModelAndView printcustomerDetails(HttpSession session) {
		
		//System.out.println(customer);
		//customerDAO.addCustomer(customer);
		ModelAndView view=new ModelAndView();
		view.setViewName("print");
		List<Customer> allCustomer = customerService.listCustomers();
		//view.addObject("allcusto", allCustomer);
		session.setAttribute("allcust",allCustomer);
		return view;
	}
	
	@RequestMapping("/customerform")
	public ModelAndView customerform() {
		
		
		ModelAndView view=new ModelAndView();
		
		System.out.println("34kjghfcy");
		view.addObject("command", new Customer());
		view.setViewName("customerform");
	
		return view;
	}
	@RequestMapping("/fetchCustomer")
	public ModelAndView fetchCustomer(Customer customer) {
		
		System.out.println("1kjghfcy");
		ModelAndView view=new ModelAndView();
		Customer retrivedCustomer=customerService.findCustomer(customer.getCustomerId());
		view.addObject("command",retrivedCustomer);
		view.setViewName("customerform");
	
		return view;
	}
	
	
	
	
}
