package com.cms.deloitte.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.model.Customer;

import co.cms.deloitte.service.CustomerService;

public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDAO customerDAO;
	
	@Override
	public boolean addCustomer(Customer customer) {
		if(customer.getBillAmount()>0)
		{	
			customerDAO.addCustomer(customer);
			System.out.println("Services Called");
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDAO.updateCustomer(customer);
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Customer> listCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer findCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDAO.findCustomer(customerId);
	}

	@Override
	public boolean isCustomerExists(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}

}
