package com.pms.deloitte.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.pms.deloitte.model.Product;
@Controller
public class ProductController
{
	@RequestMapping("/Product")
	public ModelAndView Product()
	{
		ModelAndView view =new ModelAndView("product");
		view.addObject("command",new Product());
		return view;
	}
	@RequestMapping("/addProduct")
	public ModelAndView addProduct(Product product)
	{
		ModelAndView view =new ModelAndView("product");
		System.out.println(product);
		view.addObject("command",new com.pms.deloitte.model.Product());
		return view;
	}
	@RequestMapping("/displayProduct")
	public ModelAndView displayProduct()
	{
		ModelAndView view =new ModelAndView("Display");
		return view;
	}
	@RequestMapping("/updateProduct")
	public ModelAndView updateProduct()
	{
		ModelAndView view =new ModelAndView("Update");
		return view;
	}

	@RequestMapping("/deleteProduct")
	public ModelAndView deleteProduct()
	{
		ModelAndView view =new ModelAndView("Delete");
		return view;
	}


}
