package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oracle.jrockit.jfr.RequestDelegate;

/**
 * Servlet implementation class AuthenticateServlet
 */
@WebServlet("/AuthenticateServlet")
public class AuthenticateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AuthenticateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		String username=request.getParameter("name");		
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		session.setAttribute("currentBuyer",username);
		String name= request.getParameter("name");
		Cookie allcookies[]=request.getCookies();
		boolean alreadyVisited=false;
		if (allcookies!=null)
		{
			for(Cookie c:allcookies)
			{
				if(c.getName().equals(username))
				{
					alreadyVisited=true;
					break;
				}
				
			}
		}
		if(!alreadyVisited)
		{
			out.println("Welcome,you are the first visitor"+username);
			Cookie cookie=new Cookie(username,username);
			response.addCookie(cookie);
			System.out.println("Cookie Set");
		}
		else
		{
			out.println("<h1>Welcome anyway,you have already visited");
		}
		
		out.println("<h1><form action='admin'>");
		out.println("<h1>Wife name:<input type='text'name='wifeName'>");
		out.println("<h1><input type='hidden'name='username' value="+username+">");
		out.println("<h1><input type='submit'value='Enter'>");
		out.println("<h1></form>");



	//	RequestDispatcher dispatcher=
	//				request.getRequestDispatcher("admin");
		//dispatcher.forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
