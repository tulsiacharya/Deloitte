package com.cms.deloitte.dao.impl;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.util.List;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dbconn.DBConnection;
import com.cms.deloitte.model.Customer;

public class CustomerDAOImpl implements CustomerDAO{
	
	private static final String INSERT_CUSTOMER_QUERY ="insert into hr.customer values(?,?,?,?)";
	@Override
	public boolean addCustomer(Customer customer) {
		int result=0;
		Connection connection=DBConnection.makeConnection();
		try {
			PreparedStatement statement=connection.prepareStatement(INSERT_CUSTOMER_QUERY);
			
			statement.setInt(1,customer.getCustomeId());
			statement.setString(2,customer.getCustomeName());
			statement.setString(3,customer.getCustomeAddress());
			statement.setInt(4,customer.getBillMount());
			
			result=statement.executeUpdate();
			
		} catch (Exception e) {
			
		}
		if (result==0) {
			return false;
		}else {
			return true;
		}
		
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		return false;
	}

	@Override
	public List<Customer> listCustomers() {
		return null;
	}

	@Override
	public Customer findCustomer(int customerId) {
		return null;
	}

	@Override
	public boolean checkCustomerExsist(int customerId) {
		return false;
	}

}
