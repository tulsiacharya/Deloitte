package com.cms.deloitte.client;

import java.util.Scanner;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;

public class LaunchCustomerApllication 
{
	public void startCustomerApp()
	{
		System.out.println("1.Add customer");
		System.out.println("2.Update customer");
		System.out.println("6.Exit");
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the choice");
		int choice=scanner.nextInt();
		if(choice==1)
		{
			Customer customer =new Customer();
			customer.accept();
			CustomerDAOImpl impl=new CustomerDAOImpl();
		}
	}

}
