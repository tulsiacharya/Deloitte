package project_j3;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTable 
{
	public static void main(String[] args) throws SQLException
	{
		Connection connection=DBConnection.makeConnection();
		System.out.println("CONNECTED");
		Statement statement=connection.createStatement();
		String query="create table hr.salary(salary integer,bonus integer)";
		statement.execute(query);
		System.out.println("TABLE CREATE");
		
	}
}
