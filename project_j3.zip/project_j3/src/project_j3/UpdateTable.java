package project_j3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateTable
{
	public static void main(String[] args) throws SQLException
	{
		Scanner sc=new Scanner(System.in);
		Customer customer=new Customer();
		System.out.println("Enter the id to be updated");
		int i=sc.nextInt();
		customer.setCustomeId(i);
		System.out.println("Enter the value to be updated:");
		String name=sc.next();
		customer.setCustomeName(name);
		
		String address=sc.next();
		customer.setCustomeAddress(address);
		
		int b=sc.nextInt();
		customer.setBillMount(b);
		
		Connection connection = DBConnection.makeConnection();
		PreparedStatement statement=
				connection.prepareStatement
				("update hr.customerr set cutomername=?,customeraddress=?,billammount=? where customerid=? ");
		
		
		statement.setInt(4, customer.getCustomeId());
		statement.setString(1 ,customer.getCustomeName());
		statement.setString(2, customer.getCustomeAddress());
		statement.setInt(3, customer.getBillMount());
		
		statement.executeUpdate();
		
		System.out.println(customer.getCustomeName()+"your value updated");
		
		
	}
}
