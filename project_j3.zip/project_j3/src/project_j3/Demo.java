package project_j3;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class Demo
{
	public static void main(String[] args) throws IOException 
	{
		RandomAccessFile file= new RandomAccessFile("friday.txt","rw");
		file.writeUTF("Today is friday");
		file.seek(0);
		System.out.println(file.getFilePointer());
		String str= file.readLine();
		System.out.println(str);
		file.seek(file.length());
		file.writeUTF("My name is Tulsi");
		file.seek(0);
		str= file.readLine();
		file.close();

		
		System.out.println("File contains:");
		System.out.println(str);
		
		
	}
}
