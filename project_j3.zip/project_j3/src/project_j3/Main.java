package project_j3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main
{
	public static void main(String[] args) throws SQLException
	{
		Customer customer =new Customer();
		customer.accept();
		
		Connection connection =DBConnection.makeConnection();
		PreparedStatement statement=connection.prepareStatement
				("insert into hr.customerr values(?,?,?,?)");
		statement.setInt(1, customer.getCustomeId());
		statement.setString(2 ,customer.getCustomeName());
		statement.setString(3, customer.getCustomeAddress());
		statement.setInt(4, customer.getBillMount());
		
		statement.executeUpdate();
		
		System.out.println("Record updated");
				
		
	}
}
