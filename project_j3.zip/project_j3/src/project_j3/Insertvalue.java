package project_j3;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Insertvalue 
{
	public static void main(String[] args) throws SQLException
	{
		Connection connection = DBConnection.makeConnection();
		Statement statement= connection.createStatement();
		String insertQuery="insert into hr.customerr values(100,'Sam','Bhubaneswar',45000)";
		int rows=statement.executeUpdate(insertQuery);
		System.out.println("Insert success with:"+rows);
		
	}
}
