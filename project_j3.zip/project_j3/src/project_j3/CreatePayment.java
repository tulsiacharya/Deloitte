package project_j3;

public class CreatePayment
{
	public static void main(String[] args)
	{
		Payment payment=Payment.getPaymentObject();
		payment.pay(10000);
		Payment payment1=Payment.getPaymentObject();
		payment1.pay(16780);
		

	}
}
