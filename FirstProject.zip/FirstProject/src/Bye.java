
public class Bye 
{
	public void display()
	{
		System.out.println("Thanks for visiting");
	}

}
