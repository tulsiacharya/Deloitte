package finance;

public class Salary
{
	public int calcSalaray(int a,int b)
	{
		return a+b;
	}
}
