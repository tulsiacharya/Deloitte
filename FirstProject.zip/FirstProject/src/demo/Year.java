package demo;
import java.util.*;
public class Year 
{
	public static void main(String[] args)
	{
		Scanner scanner=new Scanner(System.in);
		int year=scanner.nextInt();
		Year y=new Year();
		y.calculate(year);
	}
	public void calculate(int year)
	{
		if(year%4==0&& year%100 !=0)
		{
			System.out.println("leap year");
		}
		else if(year%400==0)
		{
			System.out.println("leap year");
		}
		else
		{
			System.out.println("not a leap year");
		}
	}
}
