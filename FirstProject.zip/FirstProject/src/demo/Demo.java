//local and instnce variable
package demo;
import java.util.Scanner;
public class Demo
{
	public void swap(int num1 ,int num2)
	{
		num1=num1+num2;
		num2=num1-num2;
		num1=num1-num2;
		System.out.println(num1+" "+num2);
	}
	public static void main(String[] args) 
	{
		Demo d= new Demo();
		Scanner scanner=new Scanner(System.in);
		int num1=scanner.nextInt();
		int num2=scanner.nextInt();
		System.out.println(num1+" "+num2);
		d.swap(num1,num2);
	}
	
	
}
