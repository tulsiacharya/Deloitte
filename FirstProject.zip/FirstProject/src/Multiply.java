
public class Multiply
{
	public void mul(int a,int b)
	{
		System.out.println("Multiplication:"+a*b);
	}
}
