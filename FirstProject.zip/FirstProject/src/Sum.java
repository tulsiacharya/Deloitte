
public class Sum
{
	public void calc()
	{
		int a=100,b=40;
		System.out.println(a+b);
	}
}
