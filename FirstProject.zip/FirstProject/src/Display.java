
public class Display
{
	public void show()
	{
		System.out.println("The sum is");
	}
}
