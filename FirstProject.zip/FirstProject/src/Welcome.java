
public class Welcome {

	public static void main(String[] args) 
	{
		System.out.println("Welcome");
		Display d=new Display();
		d.show();
		Sum s=new Sum();
		s.calc();
		Multiply m=new Multiply();
		m.mul(50, 20);
		Bye b= new Bye();
		b.display();
		finance.Salary sal=new finance.Salary();
		int res=sal.calcSalaray(34000, 4000);
		System.out.println(res);
	}

}
