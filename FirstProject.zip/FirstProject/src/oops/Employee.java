package oops;

import java.util.Scanner;


public class Employee
{
	public int employeeId;
	public String employeeName;
	public String employeeAddress;
	public int salary;
	
	public void takeSalary()
	{
		Scanner scanner=new Scanner (System.in);
		employeeId=scanner.nextInt();
		employeeName=scanner.nextLine();
		employeeAddress=scanner.nextLine();
		salary=scanner.nextInt();
		
		
	}
	public void printEmployee()
	{
		System.out.println("Employee ID:"+employeeId);
		System.out.println("Employee Name:"+employeeName);
		System.out.println("Employee Address:"+employeeAddress);
		System.out.println("Salary:"+ salary);
	}
}
